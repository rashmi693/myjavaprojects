import java.util.*;
class Video{
String videoName;
boolean checkout;
int rating;
Video(String name){ videoName=name;}
String getName(){return videoName;}
void doCheckout(){checkout=true;}
void doReturn(){checkout=false;}
void receiveRating(int R){rating=R;}
int getRating(){return rating;}
boolean getCheckout(){ return checkout;}
}
class VideoStore{
  Video store[]=new Video[20];
 int k=0;
 void addVideo(String name){ store[k++]=new Video(name);}
 void doCheckout(String name){int i;
   for( i=0;i<k;++i) 
     if(name.equals(store[i].getName()))
       break;
   store[i].doCheckout();

  }
 void doReturn(String name){int i;
   for( i=0;i<k;++i) 
     if(name.equals(store[i].getName()))
       break;
   store[i].doReturn();

   }
void receiveRating(String name,int rating){int i;
   for( i=0;i<k;++i) 
     if(name.equals(store[i].getName()))
       break;
   store[i].receiveRating(rating);
  }
void listInventery()
{
System.out.println("\nVideo Name      CheckoutStatus      Rating");
for(int i=0;i<k;++i)
System.out.println(store[i].getName()+"\t\t"+store[i].getCheckout()+"\t\t\t"+store[i].getRating()+"\n");
}

}
public class VideoLauncher{
public static void main(String arg[])
{
VideoStore vs=new VideoStore();
Scanner x=new Scanner(System.in);
int ch;
do{
System.out.println("\n MAIN MENU \n =========");
System.out.println("1.ADD VIDEO\n2.Checkout Video\n3.Return Video\n4.Receive Rating\n5.List Inventory\n6.Exit\nEnter choices (1....6):");
 ch=x.nextInt();
String name;int r;
switch(ch)
{
case 1:System.out.print("Enter the name of video you want to add :");
      name=x.next();vs.addVideo(name);System.out.println("Video "+"\""+name+"\""+" Added successfully"); break;
case 2:System.out.print("Enter the name of video you want to checkout :");
       name=x.next();vs.doCheckout(name);System.out.println("Video "+"\""+name+"\""+" checkout successfully"); break;
case 3:System.out.print("Enter the name of video you want to return :");
       name=x.next();vs.doReturn(name);System.out.println("Video "+"\""+name+"\""+" returned successfully"); break;
case 4:System.out.print("Enter the name of video you want to rate :");
       name=x.next();System.out.println("Enter the rating for this video :"); r=x.nextInt();
       vs.receiveRating(name,r);System.out.println("Rating "+"\""+r+"\""+" has been mapped to the video"+" "+name); break;
case 5:vs.listInventery(); break;
}
}while(ch!=6);
System.out.println("Exiting....!!! Thanks for using the application.");
}
}