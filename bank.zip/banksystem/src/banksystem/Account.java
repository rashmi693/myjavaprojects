/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package banksystem;

import java.util.Scanner;

/**
 *
 * @author NewUser
 */
 class Account  {
     Bank b;
     
     Account(Bank b){
         this.b=b;
     }
     void myAccount(){
         int ch,c;
           Scanner x=new Scanner(System.in);
         do{
         System.out.println("1.Create an account\n2.Search\n3.Credit\n4.Debit\n5.Compute Amount");
         ch=x.nextInt();
         switch(ch){
             case 1: b.createAccount(0);
                    break;
             case 3:System.out.println("Enter account no:");
                    String s=x.next();
                    System.out.println("Enter Ammount:");
                    double amt=x.nextDouble();
                    b.deposit(s, amt);
                    break;
             case 2: System.out.println("Enter account no:");
                       s=x.next();
                       b.showAccount(s);
                       break;
             case  4:  System.out.println("Enter account no:");
                    s=x.next();
                    System.out.println("Enter Amount:");
                    amt=x.nextDouble();
                    b.withdraw(s, amt);
                    break;   
                            
             case 5: System.out.println("Enter account no:");
                    s=x.next();
                    System.out.println("Enter Time in years:");
                    float y=x.nextFloat();
                    b.computeInterest(s, y);
                    break;    
                 
             default:System.out.println("Invalid Key Pressed!!");
                      break;
                    
           }
         System.out.println("Want to continue 1.yes 2.No?");
          c=x.nextInt();
         }while(c==1);
         }
     
     }

class Customer{
public static void main(String arg[])
{ 
    
    Scanner x=new Scanner(System.in);
         Account obj[] = new Account[3] ;
         obj[0]=new Account( new HDFC());
         obj[1]=new Account(new UnionBank());
          obj[2]=new Account(new PNB());
 do{        
System.out.println("Press 1.HDFC 2.Union Bank 3.PNB 4.Exit");
int ch=x.nextInt();
switch(ch){  
    case 1:obj[0].myAccount();
          break;
    case 2:obj[1].myAccount();
             break;
    case 3:obj[2].myAccount();
             break;
    case 4:
        System.out.println("****Total Number of Accounts ***");
        System.out.println("HDFC:"+HDFC.no+"\nUnion Bank:"+UnionBank.no);
        System.out.println("Punjab National Bank:"+PNB.no);
        System.exit(0);
         break;
       }
 }while(true);
 
}
}