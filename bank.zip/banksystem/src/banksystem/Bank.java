/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package banksystem;
/**
 *
 * @author NewUser
 */
public interface Bank {
    void createAccount(double amt);
    void showAccount(String n);
    void deposit(String s,double amt);
    void withdraw(String s,double amt);
    void computeInterest(String s,float y);
}
