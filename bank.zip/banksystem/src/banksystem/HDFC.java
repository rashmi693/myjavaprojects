/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package banksystem;

import java.text.NumberFormat;

/**
 *
 * @author NewUser
 */
class HDFC implements Bank{
      static NumberFormat ob=NumberFormat.getInstance();
     double balance[]=new double[10];
     static public int no=0;
     String account[]=new String[10];
     private final double rate=0.05;
     HDFC(){
     ob.setMaximumFractionDigits(2);
     }

    
     @Override
     public void createAccount(double amt){
     
      
      account[no]=Long.toString((long)(1000000*Math.random()));
    account[no]=account[no].replaceAll(",","");
      balance[no]=amt;
      System.out.println("****Your Account is created Successfully***");
      System.out.println("Account no: "+account[no]);
      System.out.println("Account Balance: "+balance[no]);
      System.out.println("Interest Rate: "+rate);
      no++;
   }

    

    @Override
    public void showAccount(String s) {
        int n=searchIndex(s);
        if(n!=-1)
        System.out.println("Balance: "+balance[n]); 
        else
            System.out.println("Invalid account no");
//To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void deposit(String s,double amt) {
      int n= searchIndex(s);
     if(n==-1)
         System.out.println("Not a valid account no");
     else 
     { 
         balance[n]=balance[n]+amt;
     System.out.println("Your account "+account[n]+" is credited succesfully. Your current Balance: "+balance[n]);
     }

     }
    


    @Override
    public void withdraw(String s,double amt) {  
       int n= searchIndex(s);
     if(n==-1)
         System.out.println("Not a valid account no");
     else
      if(balance[n]>=amt)
      {  balance[n]=balance[n]-amt;
     System.out.println("Your account "+account[n]+" is debited with amount "+amt+"Your current balance is "+balance[n]);
     }
     else
          System.out.println("---Insufficient Amount----");
        //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void computeInterest(String s,float y) {
        int n=searchIndex(s);
        if(n!=-1)
        {
            System.out.println("Your  current Balance: "+balance[n]);
        double res=balance[n]*Math.pow((1+rate),y);
        System.out.println("Your Balance after "+y+" years will be "+ob.format(res));
        }
        
        //To change body of generated methods, choose Tools | Templates.
    }
  int searchIndex(String s)
  {
  for(int i=0;i<no;++i)
    if(account[i].equals(s))
        return i;
  return -1;
  
  }
}
