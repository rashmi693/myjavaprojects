/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bank;

import java.util.Scanner;

/**
 *
 * @author NewUser
 */
class Account{
     void myAccount(Bank b){
         
         int ch,i=0;
         String c;
           Scanner x=new Scanner(System.in);
         do{
         System.out.println("1.Create an account 2.Credit  3.Debit 4.Check balance 5.Close Account ");
         ch=x.nextInt();
         switch(ch){
             case 1: System.out.println("Enter the account type 1.Saving 2.Current");
                     int k=x.nextInt();
                     if(k==1)
                         b.createAccount("Saving");
                     else
                         b.createAccount("Current"); 
                    break;
             case 2: b.deposit();
                       break;
             case 3:b.withdraw();
                       break;
             case  4: System.out.print("Your current Balance: "+b.getBalance());
                       break;    
             case 5:b.closeAccount();
                       break;
             default:System.out.println("Invalid Key Pressed!!");
                      break;
                    
           }
         System.out.println("\nPress C TO continue and E to exit");
          c=x.next();
         }while(c.equalsIgnoreCase("C"));
         }
}
public class Customer {
    public static void main(String arg[])
    {
    Scanner x=new Scanner(System.in);
    Account xyz=new Account();
    
do
{        
System.out.println(" 1.Axis 2.ICICI 3.StateBank 4.Exit");
int ch=x.nextInt();
switch(ch){  
    case 1:xyz.myAccount(new AXIS());
          break;
    case 2:xyz.myAccount(new ICICI());
          break;
    case 3:xyz.myAccount(new StateBank());
          break;
    case 4:System.exit(0);
         break;
       }
 }while(true);

}
}







