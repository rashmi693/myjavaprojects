/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bank;

import java.util.Scanner;

/**
 *
 * @author NewUser
 */
class StateBank implements Bank{
   private double rate;
    double balance;
    String name;
    int acno;
    static int i;
    Scanner x;

    StateBank() {
         x=new Scanner(System.in);//To change body of generated methods, choose Tools | Templates.
    }
   
    @Override
    public void createAccount(String s) {
        this.getCustomerdetails();
      if(s.equals("Saving"))
          rate=0.03;
      else
         rate=0;
      balance=0;
      System.out.println("Your Account is created!!");
      System.out.println("Account no:"+acno);
      System.out.println("Balance:"+balance);
//To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void closeAccount() {
      name=null;
      balance=0;
       System.out.println("Your Account is Closed!!");
              //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void deposit() {
        System.out.println("Enter the amount:");
        double amt=x.nextInt();
        
           balance+=amt;
            System.out.println("Your Account is credited and Your balance is "+balance);
        //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void withdraw() {
        System.out.println("Enter the amount:");
        double amt=x.nextInt();
        if(balance>amt)
           balance-=amt;
        System.out.println("Your Account is debited with "+amt +"and Your balance is "+balance);
    }

    @Override
    public double getBalance() {
        return balance; //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void getCustomerdetails() {
        System.out.println("Enter Customer Name: ");
        name=x.next();
        acno=i++;
          
//To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void findCustomer() {
        //To change body of generated methods, choose Tools | Templates.
    }

}